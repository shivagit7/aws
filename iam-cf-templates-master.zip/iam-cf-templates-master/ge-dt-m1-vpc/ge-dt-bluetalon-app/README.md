# Attention

This template converted to YAML and refactored as a new 'generic' version of the policy that will take some parameters to accommodate the differences between the environments.

For historical reasons the name of the CF stack is different between us4p and us9p. We need to keep it the same to avoid having to delete the (already created) role

Because the stack names differ, we need to create 2 different files - us4p.yml and us9p.yml so we can run only 1 of the stacks

You MUST specify which config file to use when running
i.e.
```
stack_master apply -c us9p.yml
```
