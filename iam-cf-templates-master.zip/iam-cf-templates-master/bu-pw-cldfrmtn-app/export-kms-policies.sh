echo "Exporting all the policies for all keys which do have an alias defined"
aws kms list-aliases --output text --query 'Aliases[].[TargetKeyId, AliasName]' \
	| while read KeyId AliasName
	  do
	  	[ 'None' == $KeyId ] && echo "Skipping $AliasName" && continue
	  	FN="${KeyId}.$(echo $AliasName | sed -e 's|^alias/||' -e 's|^aws/||').json"
	  	aws kms get-key-policy --key-id $KeyId --policy-name default | sed -e 's/\\"/"/g' -e 's/\\n/\n/g' > $FN
	  done

echo ""	
echo "For all other keys (which did not have an alias defined)"
aws kms list-keys --output text --query 'Keys[].[KeyId, KeyArn]' \
	| while read KeyId KeyArn
	  do
	  	#ls $KeyId\.*.json 2>&1 | grep -q "^$KeyId"; [ 0 -eq $? ] && echo "Skipping $KeyId" && continue
	  	ls $KeyId\.*.json 2>&1 | grep -q "^$KeyId"; [ 0 -eq $? ] && continue
	  	echo "Creating file ${KeyId}.json"
	  	aws kms get-key-policy --key-id $KeyId --policy-name default | sed -e 's/\\"/"/g' -e 's/\\n/\n/g' > ${KeyId}.json
	  done

echo ""	  
echo "Which KMS key policies have references to bu-pw-cldfrmtn-app role ?"
grep '"AWS" :' *.json | grep 'bu-pw-cldfrmtn-app'

echo ""	  
echo "Which KMS key policies have references to a role which no longer exist or were redone ?"
grep '"AWS" :' *.json | sed 's/,/\n/g' | grep -v '"arn:aws:iam'

exit 0

grep '"AWS"' 71a952db-e05e-48fe-bfbc-75f26415046d.pwr-coreami-us1n-key.json | sed 's/,/\n/g' | grep -v '"arn:aws:iam'


$ grep '"AWS" : "' *.json | grep 'bu-pw-cldfrmtn-app'
3fba9e08-aa2f-4abd-ba99-67368aed0c1e.cfgen-test-key.json:      "AWS" : "arn:aws:iam::930136447543:role/hq/bu-pw-cldfrmtn-app"
3fba9e08-aa2f-4abd-ba99-67368aed0c1e.cfgen-test-key.json:      "AWS" : "arn:aws:iam::930136447543:role/hq/bu-pw-cldfrmtn-app"
a25ce0f1-10ed-4876-89a0-4cc0e64db135.us1n-trackntrace.json:      "AWS" : "arn:aws:iam::930136447543:role/hq/bu-pw-cldfrmtn-app"
a25ce0f1-10ed-4876-89a0-4cc0e64db135.us1n-trackntrace.json:      "AWS" : "arn:aws:iam::930136447543:role/hq/bu-pw-cldfrmtn-app"
e6dc1137-2282-4766-abb5-cc43daecdb29.renewables-control-systems-lab.json:      "AWS" : "arn:aws:iam::930136447543:role/hq/bu-pw-cldfrmtn-app"
e6dc1137-2282-4766-abb5-cc43daecdb29.renewables-control-systems-lab.json:      "AWS" : "arn:aws:iam::930136447543:role/hq/bu-pw-cldfrmtn-app"


$ grep '"AWS" : "' *.json | grep -v '"AWS" : "arn' | grep -v '"AWS" : "\*"'
4ca105d6-db37-4629-9270-4fa1c2580e1a.us1n-customerexperience_appdb.json:      "AWS" : "AROAIXIOGT6DQ5SCHZOIU"
85a49da7-2f6e-4b24-9767-4c95d1472b77.bu-pw-ssc-buyerportal-us1n.json:      "AWS" : "AROAIVDVOV3LBGEM7HGLE"
85a49da7-2f6e-4b24-9767-4c95d1472b77.bu-pw-ssc-buyerportal-us1n.json:      "AWS" : "AROAIVDVOV3LBGEM7HGLE"
87ba8d96-716b-4c83-97d5-20db8bd66527.us1n-dms.json:      "AWS" : "AROAJDHSRSPMPLQH4N46K"
ad387466-cfb2-4453-9948-82432761ccce.maytradi-auth.json:      "AWS" : "AROAIUPKKKLKO4TPTK2V6"
b3a415de-7e4b-4647-a755-2f1a3434f79f.ops-slack-powerops.json:      "AWS" : "AROAJDHSRSPMPLQH4N46K"
b3a415de-7e4b-4647-a755-2f1a3434f79f.powerops-lambda-secrets.json:      "AWS" : "AROAJDHSRSPMPLQH4N46K"
c30483b1-4209-47d6-a366-f0842918a962.pulse-auth.json:      "AWS" : "AROAIBZ33JX2TKE25DS2Q"


aws kms list-keys --output text --query 'Keys[].[KeyId, KeyArn]' | while read KeyId KeyArn; do
	ls $KeyId\.*.json 2>&1 | grep -q "^$KeyId" || { echo "Skipping $KeyId"; continue }
	#PolicyNames=$(aws kms list-key-policies --output text --query 'PolicyNames' --key-id $KeyId)
	#for PolName in "$PolicyNames"; do aws kms get-key-policy --key-id $KeyId --policy-name $PolName; done
	aws kms get-key-policy --key-id $KeyId --policy-name default | sed -e 's/\\"/"/g' -e 's/\\n/\n/g' > ${KeyId}.json
	
	
aws kms list-keys --output text --query 'Keys[].[KeyId, KeyArn]' | while read KeyId KeyArn; do ls $KeyId\.*.json 2>&1 | grep -q "^$KeyId"; [ 0 -eq $? ] && echo "Skipping $KeyId" && continue; echo "Creating file ${KeyId}.json"; aws kms get-key-policy --key-id $KeyId --policy-name default | sed -e 's/\\"/"/g' -e 's/\\n/\n/g' > ${KeyId}.json; done	


$ aws kms describe-key --key-id dca26146-be1d-458a-a408-604e3b0759e5
{
    "KeyMetadata": {
        "Origin": "AWS_KMS",
        "KeyId": "dca26146-be1d-458a-a408-604e3b0759e5",
        "Description": "us1n-snaplogicproxy",
        "KeyManager": "CUSTOMER",
        "Enabled": true,
        "KeyUsage": "ENCRYPT_DECRYPT",
        "KeyState": "Enabled",
        "CreationDate": 1464788621.333,
        "Arn": "arn:aws:kms:us-east-1:930136447543:key/dca26146-be1d-458a-a408-604e3b0759e5",
        "AWSAccountId": "930136447543"
    }
}

$ aws kms list-key-policies --key-id dca26146-be1d-458a-a408-604e3b0759e5
{
    "PolicyNames": [
        "default"
    ]
}
