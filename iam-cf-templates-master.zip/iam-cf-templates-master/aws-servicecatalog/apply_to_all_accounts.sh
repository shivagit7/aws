#!/bin/bash -e

PROFILES=( pnw-preprod_bu-iam-admin  pnw-prod-iam-admin us4n-iam-admin )

for profile in "${PROFILES[@]}"
do
  echo "==========================================================="
  echo "Running apply using profile: ${profile}"
  echo "==========================================================="

  AWS_PROFILE=${profile} stack_master apply

  echo
done
