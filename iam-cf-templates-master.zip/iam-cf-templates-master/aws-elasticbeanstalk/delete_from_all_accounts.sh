#!/bin/bash -e

PROFILES=( us1p/bu-iam-admin us1n/bu-iam-admin )

for profile in "${PROFILES[@]}"
do
  echo "==========================================================="
  echo "Running delete using profile: ${profile}"
  echo "==========================================================="

  AWS_PROFILE=${profile} stack_master delete us-east-1 iam-beanstalk-service-role

  echo
done
