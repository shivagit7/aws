#!/bin/bash -e

# We're just using profiles, so clear any credential variables
unset AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY AWS_SESSION_TOKEN

PROFILES=( us1n/bu-iam-admin us1p/bu-iam-admin )

for profile in "${PROFILES[@]}"
do
  echo "==========================================================="
  echo "Running apply using profile: ${profile}"
  echo "==========================================================="

  AWS_PROFILE=${profile} stack_master apply "$@"

  echo
done
