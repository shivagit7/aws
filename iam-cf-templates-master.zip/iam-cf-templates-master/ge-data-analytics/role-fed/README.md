### Roles
-------------------
Currently following roles are covered and can be deployed in any new VPC by using `stack_master apply us-east-1 -y` whereas us-east-1 may have to be changed to the region used in your specific case.
```
hq/bu-pw-cldmgmt-fed
hq/bu-pw-cldadmin-fed
hq/bu-pw-cldauto-fed
hq/bu-pw-cldwebops-fed
hq/bu-pw-cldarch-fed
hq/bu-pw-clddba-fed
```
You als need to create DLs in case you are going to deploy it to a new VPC, the name needs to follow this format

`@GE AWS_<VPC-NAME>_hq/<ROLE-NAME>_<ACCOUNT-NUMBER>`

As and example if your VPC does have an Accountname of *my-new-vpc* and an AccountNumber of *123456789* you need to create the following DLs within IDM to cover all the roles: 

```
@GE AWS_my-new-vpc_hq/bu-pw-cldmgmt-fed_123456789
@GE AWS_my-new-vpc_hq/bu-pw-cldadmin-fed_123456789
@GE AWS_my-new-vpc_hq/bu-pw-cldauto-fed_123456789
@GE AWS_my-new-vpc_hq/bu-pw-cldwebops-fed_123456789
@GE AWS_my-new-vpc_hq/bu-pw-cldarch-fed_123456789
@GE AWS_my-new-vpc_hq/bu-pw-clddba-fed_123456789
```
