This is for the cloudtools application - UAI2004397

See documentation for the Propel setup at https://devcloud.swcoe.ge.com/devspace/display/LDLUN/How+to+integrate+with+Propel and the README.md in folder ../propel/

Also see the comments in us6n.yml on how to execute until we have an automated deployment pipeline

The stack_master config file us6n.yml contains Lab stacks to exist in us6n VPC Eventually a us1p.yml should be created for PRD envs
