#!/bin/bash
BUILDSTATUS=0

# loop & print a folder recusively,
validate_json_recurse() {
    for i in "$1"/*;do
        if [ -d "$i" ];then
            validate_json_recurse "$i"
        elif [ -f "$i" ];then
          if [[ $i =~ ".*\.(js|json)" ]];then
            echo "file: $i"
            jsonlint $i -q
            RETVAL=$?
            if [[ $RETVAL -eq 1 ]];then
              BUILDSTATUS=1
            fi
          fi
        fi
    done
}

validate_json_recurse $PWD
exit $BUILDSTATUS
