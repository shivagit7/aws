# IAM Requests
This repository stores the actual state of all custom IAM roles, users, groups and policies for all of the Power management VPCs.

Please ensure to follow the [tagging Standards](https://devcloud.swcoe.ge.com/devspace/display/TKUWA/AWS+General+Tagging+Standard) at a minimum! 
Any exception or special treatment are described below.

## How to request a change or a new role
You need to create a new issue at https://github.build.ge.com/power-cloud/iam-cf-templates/issues which does provide following information
- Name of the role
- Purpose and scope (what services and the required privileges)
- Which Account(s) (VPC)
- The audience/members using that role in case its a federated role

As soon you have an issue submitted you can create the necessary templates with **stack_master** (required and available at https://github.com/envato/stack_master) and create a pull request.
This Pull request have to be linked to the issue, pull requests without such a link will be removed after 1 day without processing !

## Some clues on stack_master
### Required properties to include
If you create a new `stack_master.yml` (using `stack_master init`) or you are adjusting an existing one, please ensure following portions are included in the file:

#### This should be placed on top
This ensures that all stacks are getting those **required** tags applied!
```
stack_defaults:
  tags:
    stack: <DIRECTORY in iam-cf-templates repository>
    uai: <UAI of Application>
    assetid: <ASSETID of CMDB Asset>
```
#### Individual tags need to be incorporated into the stack_definitions (currently only env)
```
stacks:
  region_or_alias:
    eu-west-1:
      my-stack-name-prd:
        template: my_stack_template.json
        tags:
          env: prd
      my-stack-name-stg:
        template: my_stack_template.json
        tags:
          env: stg
```

### General

In a lot of the cases you may have to create an instance profile which is able to access s3, in such a case you should always use the already exisiting **universal** role available and just add 
1. A yml identifiying the stack (just copy one and adjust the names in the template)
2. Copy a parameter file, rename it and adjust the content

In case a new role is required the best approach is to create a new structure with stack_master by using the following command `stack_master init [region] [stack_name]` whereas region is either __us-east-1__ or __eu-west-1__ and the stack_name can be chosen but should follow this pattern: bu-pw-__P&L__-__APP-NAME__-__[app|fed]__

If you have a role which applies to multiple regions you should adapt your stack_master.yml file to be able to deal with that and address the different environments probably, following example shows a stack_master.yml which can be enrolled into us-east-1 as well as eu-west-1

```
region_aliases:
  us1n: us-east-1
  eu1n: eu-west-1
stack_defaults:
  tags:
    stack: bu-pw-gps-myapp-app
    uai: UAI1234567
    assetid: 12345678
stacks:
  us1n:
    bu-pw-gps-myapp-app:
      template: bu-pw-gps-myapp.cf.json
      tags:
        env: dev
  eu1n:
    bu-pw-gps-myapp-app:
      template: bu-pw-gps-myapp.cf.json
      tags:
        env: stg
```

The parameter files in such a case can be stored in `parameters/us1n/bu_pw_gps_myapp_app.yml` or `parameters/eu1n/bu_pw_gps_myapp_app.yml`(please recognise the underlines instead of the dashes, this is by design !)
The template can be extended the same way ! You can ignore the tags, we will use them in future to identify the location of the role, user or group in github.

* stack_master have to be used ( https://github.com/envato/stack_master )
* Universal role: https://github.build.ge.com/power-cloud/iam-cf-templates/tree/master/universal
